import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

import { useTheme } from '@/src/hooks/useTheme';
import { radius, spacing } from '@/src/theme/spacing';
import { typography } from '@/src/theme/typography';

interface DashboardHeaderProps {
  avatar?: string;
  greeting: string;
  greetingName: string;
  onNotifications?: () => void;
}

export function DashboardHeader({
  avatar,
  greeting,
  greetingName,
  onNotifications,
}: DashboardHeaderProps) {
  const { colors, isDark } = useTheme();

  const getInitials = () => {
    return greetingName.split(' ').map((n) => n[0]).join('').toUpperCase().substring(0, 2);
  };

  return (
    <LinearGradient
      colors={isDark ? ['#1a1030', '#0a0b10'] : ['#a2cbfd', '#f7bee9']}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[styles.container, { borderBottomColor: colors.outline }]}>
      {/* Profile Row */}
      <View style={styles.profileRow}>
        <View style={styles.profileLeft}>
          <View style={[styles.avatar, { borderColor: colors.outline }]}>
            <Text style={[styles.avatarText, { color: isDark ? colors.primary : '#0f172a' }]}>
              {getInitials()}
            </Text>
          </View>
          <View style={styles.greetingCol}>
            <Text style={[styles.eyebrow, { opacity: 0.6 }]}>{greeting}</Text>
            <Text style={[styles.name, { color: isDark ? colors.onSurface : '#0f172a' }]}>
              {greetingName}
            </Text>
          </View>
        </View>
        <Pressable onPress={onNotifications} style={[styles.bellButton, { backgroundColor: colors.surface }]}>
          <Feather name="bell" size={18} color={colors.primary} />
        </Pressable>
      </View>

      {/* Search Bar */}
      <View style={[styles.searchBar, { backgroundColor: colors.surface }]}>
        <Feather name="search" size={16} color={colors.onSurfaceVariant} />
        <TextInput
          placeholder="Passive cognitive telemetry active..."
          placeholderTextColor={colors.onSurfaceVariant}
          style={[styles.searchInput, { color: colors.onSurface }]}
          editable={false}
        />
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 54,
    paddingBottom: 28,
    paddingHorizontal: spacing.gutter,
    borderBottomLeftRadius: 36,
    borderBottomRightRadius: 36,
    borderBottomWidth: 1,
    gap: spacing.md,
  },
  profileRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  profileLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    flex: 1,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 18,
    fontWeight: '700',
  },
  greetingCol: {
    gap: 2,
  },
  eyebrow: {
    ...typography.labelCaps,
    textTransform: 'none',
  },
  name: {
    fontSize: 20,
    fontWeight: '700',
  },
  bellButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchBar: {
    flexDirection: 'row',
    height: 46,
    borderRadius: 23,
    paddingHorizontal: 16,
    gap: 10,
    alignItems: 'center',
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    fontWeight: '500',
  },
});
